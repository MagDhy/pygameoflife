from pygameoflife.LifeGame import LifeGame

LifeGame().run()
